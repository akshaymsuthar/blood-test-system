from django.apps import AppConfig


class LaboratoryappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'laboratoryapp'
